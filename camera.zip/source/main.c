#include "cybsp.h"
#include "cy_retarget_io.h"
#include "FreeRTOS.h"
#include "task.h"
#include "z_inc/wifi_task.h"          /* create_wifi_task() */
#include "z_inc/cam_task.h"           /* create_camera_tasks() */

int main(void)
{
    cybsp_init();
    cy_retarget_io_init(CYBSP_DEBUG_UART_TX, CYBSP_DEBUG_UART_RX, 115200);
    __enable_irq();

    create_wifi_task();        //WIFI任务
    create_camera_tasks();     //摄像头任务

    vTaskStartScheduler();
    for(;;);                    /* 不会执行到这里 */
}
