#ifndef WIFI_TASK_H_
#define WIFI_TASK_H_

/* 创建 Wi-Fi 任务 */
void create_wifi_task(void);

#endif /* WIFI_TASK_H_ */
