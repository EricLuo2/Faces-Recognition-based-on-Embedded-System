#include "lwip/sockets.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include <stdio.h>
#include "../z_inc/app_cfg.h"
#include "../z_inc/ptc06.h"
#include "../z_inc/uart_hal.h"
#include "../z_inc/cam_task.h"
#include <string.h>
#include <stdlib.h>
#include <errno.h>

extern volatile bool wifi_connected;

// 常量定义
// #define BUFFER_SIZE 1024  // 不再直接使用
// #define READ_CHUNK 512   // 不再直接使用
#define SEND_CHUNK 256   // 每次发送256字节, network_task仍在使用

// 全局图像缓冲区
static image_buffer_t g_image_buffer = {0};
static uint8_t s_camera_image_buffer[PTC06_MAX_IMAGE_BUFFER_SIZE]; // 新增静态缓冲区

// 数据包头部结构
#pragma pack(1)
typedef struct {
    uint8_t  magic[2];    // 固定为 'PH' (Photo Header)
    uint32_t total_size;  // 图片总大小
    uint32_t offset;      // 当前数据块的偏移
    uint16_t chunk_size;  // 当前数据块的大小
    uint8_t  is_last;     // 是否是最后一个数据块
} packet_header_t;
#pragma pack()

// 发送数据块函数
static bool send_data_block(int sock, const uint8_t* data, uint32_t total_size,
                          uint32_t offset, uint16_t chunk_size, bool is_last) {
    packet_header_t header = {
        .magic = {'P', 'H'},
        .total_size = total_size,
        .offset = offset,
        .chunk_size = chunk_size,
        .is_last = is_last ? 1 : 0
    };

    // 发送头部
    if (send(sock, &header, sizeof(header), 0) != sizeof(header)) {
        printf("[cam] failed to send header at offset %u\n", offset);
        return false;
    }

    // 发送数据
    if (send(sock, data, chunk_size, 0) != chunk_size) {
        printf("[cam] failed to send data at offset %u\n", offset);
        return false;
    }

    printf("[cam] sent block: offset=%u size=%u%s\n",
           offset, chunk_size, is_last ? " (last block)" : "");
    return true;
}

// 相机任务 - 负责从相机读取数据
static void camera_task(void *arg) {
    cyhal_uart_t *uart = uart_hal_obj();
    uint32_t actual_image_len = 0; // 用于存储实际读取的图像长度
    
    // 初始化相机
    if (!ptc06_init(uart)) {
        printf("[cam] camera init failed\n");
        vTaskDelete(NULL);
        return;
    }
    
    printf("[cam] camera initialized\n");
    
    while(1) {
        // 清理缓存 - 移至拍照尝试之后
        // if (!ptc06_clear_cache(uart)) {
        //     vTaskDelay(pdMS_TO_TICKS(1000));
        //     continue;
        // }
        
        // 拍照
        printf("[cam] taking picture...\n");
        if (!ptc06_take_picture(uart)) {
            printf("[cam] failed to take picture.\n");
            if (!ptc06_clear_cache(uart)) { // 拍照失败也尝试清理缓存
                 printf("[cam] Warning: failed to clear cache after take_picture failure.\n");
            }
            vTaskDelay(pdMS_TO_TICKS(2000)); // 拍照失败后延时
            continue;
        }
        printf("[cam] picture taken successfully.\n");
        
        // 获取图片大小 & 读取图片数据 - 使用新函数
        // uint16_t img_len = 0; // 不再需要单独获取长度
        // if (!ptc06_get_length(uart, &img_len) || img_len == 0) {
        //     ptc06_clear_cache(uart); 
        //     continue;
        // }
        // printf("[cam] image length: %u bytes\n", img_len);
        
        // 在读取图片前增加更多延时，让相机完全准备好 - 这个延时现在在 ptc06_read_image_to_buffer 内部
        // printf("[cam] waiting 5 seconds before starting image read...\n");
        // vTaskDelay(pdMS_TO_TICKS(5000));
        
        // 分配内存 - 将使用 s_camera_image_buffer
        // uint8_t *buffer = pvPortMalloc(img_len); // 不再需要动态分配这个buffer
        // if (!buffer) {
        //     printf("[cam] failed to allocate buffer\n");
        //     ptc06_clear_cache(uart);
        //     continue;
        // }
        
        // 读取图片数据 - 调用新函数
        printf("[cam] attempting to read image into static buffer...\n");
        bool read_ok = ptc06_read_image_to_buffer(uart, s_camera_image_buffer, 
                                                 sizeof(s_camera_image_buffer), &actual_image_len);
        
        if (read_ok && actual_image_len > 0) {
            printf("[cam] image read to static buffer successfully, %lu bytes.\n", actual_image_len);

            xSemaphoreTake(g_image_buffer.mutex, portMAX_DELAY);
            if (g_image_buffer.data) { // Free previous data if any
                vPortFree(g_image_buffer.data);
                g_image_buffer.data = NULL;
            }
            g_image_buffer.data = pvPortMalloc(actual_image_len);
            if (g_image_buffer.data) {
                memcpy(g_image_buffer.data, s_camera_image_buffer, actual_image_len);
                g_image_buffer.size = actual_image_len;
                g_image_buffer.ready = true;
                printf("[cam] image copied to g_image_buffer (%lu bytes).\n", actual_image_len);
                xSemaphoreGive(g_image_buffer.mutex);
                xSemaphoreGive(g_image_buffer.data_ready); // 通知网络任务
                printf("[cam] image ready for transmission notification sent.\n");
            } else {
                printf("[cam] CRITICAL: Failed to allocate memory for g_image_buffer.data (%lu bytes).\n", actual_image_len);
                g_image_buffer.size = 0;
                g_image_buffer.ready = false;
                xSemaphoreGive(g_image_buffer.mutex);
            }
        } else {
            if (!read_ok) {
                 printf("[cam] CRITICAL: failed to read image into buffer from ptc06_read_image_to_buffer.\n");
            } else if (actual_image_len == 0) {
                 printf("[cam] image read from ptc06_read_image_to_buffer but length is 0.\n");
            }
        }
        
        // 移除旧的读取逻辑
        // uint32_t total_read = 0;
        // bool read_success = true;
        // printf("[cam] starting image data read sequence...\n");
        // while (total_read < img_len) { ... old block read loop ... }
        // if (read_success && total_read == img_len) { ... }
        // else { vPortFree(buffer); }
        
        // 总是尝试清理缓存
        printf("[cam] cycle end, clearing camera cache...\n");
        if (!ptc06_clear_cache(uart)) {
            printf("[cam] Warning: failed to clear camera cache at end of cycle.\n");
        }
        printf("[cam] Next capture in 1 minute...\n"); // 添加日志提示
        vTaskDelay(pdMS_TO_TICKS(60000)); // 修改延时为10秒
    }
}

// 网络任务 - 负责发送数据
static void network_task(void *arg) {
    // 等待WiFi连接
    while (!wifi_connected) {
        printf("[net] waiting for wifi...\n");
        vTaskDelay(pdMS_TO_TICKS(500));
    }
    printf("[net] wifi connected\n");
    
    while (1) {
        // 等待新图片数据
        if (xSemaphoreTake(g_image_buffer.data_ready, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        
        // 获取数据
        xSemaphoreTake(g_image_buffer.mutex, portMAX_DELAY);
        uint8_t *data = g_image_buffer.data;
        uint32_t size = g_image_buffer.size;
        g_image_buffer.ready = false;
        xSemaphoreGive(g_image_buffer.mutex);
        
        if (!data || size == 0) {
            continue;
        }
        
        printf("[net] attempting to send image (%u bytes)\n", size);
        
        // 建立TCP连接
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
            printf("[net] socket creation failed: %d (%s)\n", errno, strerror(errno));
            goto cleanup;
        }
        
        // 配置socket选项
        int keepalive = 1;
        int keepcnt = 3;
        int keepidle = 10;
        int keepintvl = 5;
        int timeout = 5000; // 5 seconds timeout
        
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(keepalive));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &keepcnt, sizeof(keepcnt));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &keepidle, sizeof(keepidle));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &keepintvl, sizeof(keepintvl));
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
        
        struct sockaddr_in dst = {0};
        dst.sin_family = AF_INET;
        dst.sin_port = htons(SERVER_PORT);
        dst.sin_addr.s_addr = inet_addr(SERVER_IP);
        
        printf("[net] connecting to %s:%d...\n", SERVER_IP, SERVER_PORT);
        
        if (connect(sock, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
            printf("[net] connect failed: %d (%s)\n", errno, strerror(errno));
            close(sock);
            goto cleanup;
        }
        
        printf("[net] connected, starting transmission\n");
        
        // 发送图片数据
        uint32_t total_sent = 0;
        bool send_success = true;
        
        while (total_sent < size) {
            uint16_t to_send = (size - total_sent) > SEND_CHUNK ? 
                              SEND_CHUNK : (size - total_sent);
            bool is_last = (total_sent + to_send) >= size;
            
            if (!send_data_block(sock, data + total_sent, size,
                               total_sent, to_send, is_last)) {
                printf("[net] failed to send at offset %u\n", total_sent);
                send_success = false;
                break;
            }
            
            total_sent += to_send;
            printf("[net] progress: %u/%u bytes (%d%%)\n",
                   total_sent, size, (total_sent * 100) / size);
                   
            vTaskDelay(pdMS_TO_TICKS(50));  // 发送之间的短暂延时
        }
        
        if (send_success) {
               printf("[net] image sent successfully\n");
        }
        
        close(sock);
        
cleanup:
        // 清理
        xSemaphoreTake(g_image_buffer.mutex, portMAX_DELAY);
        vPortFree(g_image_buffer.data);
        g_image_buffer.data = NULL;
        g_image_buffer.size = 0;
        xSemaphoreGive(g_image_buffer.mutex);
        
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void create_camera_tasks(void) {
    // 初始化同步对象
    g_image_buffer.mutex = xSemaphoreCreateMutex();
    g_image_buffer.data_ready = xSemaphoreCreateBinary();
    
    if (!g_image_buffer.mutex || !g_image_buffer.data_ready) {
        printf("[cam] failed to create synchronization objects\n");
        return;
    }
    
    // 创建任务
    BaseType_t ret;
    
    ret = xTaskCreate(camera_task, "camera", 4096, NULL, 4, NULL);
    if (ret != pdPASS) {
        printf("[cam] failed to create camera task\n");
        return;
    }
    
    ret = xTaskCreate(network_task, "network", 4096, NULL, 4, NULL);
    if (ret != pdPASS) {
        printf("[cam] failed to create network task\n");
        return;
    }
    
    printf("[cam] tasks created successfully\n");
}



/*
 *
 * 以下代码用于测试连接发送
 *
 *摄像头完整任务在上面
 *
 */
//
//
//#include "lwip/sockets.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include <stdio.h>
//#include "../z_inc/app_cfg.h"
//#include "../z_inc/ptc06.h"
//#include "../z_inc/uart_hal.h"
//#include <string.h>
//#include <stdlib.h>
//
//
//static const uint8_t TEST_IMAGE_FILE_DATA[] = {
//    0xFF, 0xD8, 0xFF, 0xFE, 0x00, 0x24, 0x67, 0x05, 0x56, 0x23, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x00, 0x40, 0x01, 0x2E, 0x00, 0x32, 0x12, 0x0B, 0x51, 0x04,
//    0x51, 0x04, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x84, 0x00, 0x0C, 0x08, 0x09, 0x0A, 0x09, 0x07, 0x0C,
//    0x0A, 0x09, 0x0A, 0x0D, 0x0C, 0x0C, 0x0E, 0x11, 0x1D, 0x13, 0x11, 0x10, 0x10, 0x11, 0x23, 0x19,
//    0x1B, 0x15, 0x1D, 0x2A, 0x25, 0x2C, 0x2B, 0x29, 0x25, 0x28, 0x28, 0x2E, 0x34, 0x42, 0x38, 0x2E,
//    0x31, 0x3F, 0x32, 0x28, 0x28, 0x3A, 0x4E, 0x3A, 0x3F, 0x44, 0x46, 0x4A, 0x4B, 0x4A, 0x2D, 0x37,
//    0x51, 0x57, 0x51, 0x48, 0x56, 0x42, 0x49, 0x4A, 0x47, 0x01, 0x0C, 0x0D, 0x0D, 0x11, 0x0F, 0x11,
//    0x22, 0x13, 0x13, 0x22, 0x47, 0x2F, 0x28, 0x2F, 0x47, 0x47, 0x47, 0x47, 0x47, 0x47, 0x47, 0x47
//};
//
//static const size_t img_len = sizeof(TEST_IMAGE_FILE_DATA) / sizeof(TEST_IMAGE_FILE_DATA[0]);
//
//extern volatile bool wifi_connected;  // 引用wifi连接状态
//
//
//static void cam_task(void *arg) {
////    if (!ptc06_init(uart_hal_obj())) {
////        printf("[cam] init fail\n");
////        vTaskDelete(NULL);
////    }
//
//	while (!wifi_connected)
//		    {
//		        printf("[cam] waiting for wifi...\n");
//		        vTaskDelay(pdMS_TO_TICKS(500));
//		    }
//
//	printf("[cam] wifi connected, start capturing...\n");
//
//    uint8_t *buf = pvPortMalloc(CHUNK_SIZE);  // 动态分配内存
//
//    if (buf == NULL) {
//        printf("[cam] 无法分配内存\n");
//        vTaskDelete(NULL);
//    }
//
//    const uint8_t *image_data = TEST_IMAGE_FILE_DATA; // 使用测试图像数据数组
//
//    // 发送图像数据
//    int sock = socket(AF_INET, SOCK_STREAM, 0);
//    struct sockaddr_in dst = {0};
//    dst.sin_family = AF_INET;
//    dst.sin_port = htons(SERVER_PORT);
//    dst.sin_addr.s_addr = inet_addr(SERVER_IP);
//
//    if (connect(sock, (struct sockaddr*)&dst, sizeof(dst)) < 0) {
//        printf("[cam] tcp connect fail, error: %d\n", errno);
//        close(sock);
//        free(buf);
//        vTaskDelete(NULL);
//    }
//
//    // 分块发送图像数据
//    for (size_t off = 0; off < img_len; off += CHUNK_SIZE) {
//        size_t blk = (img_len - off > CHUNK_SIZE) ? CHUNK_SIZE : (img_len - off);
//
//        memcpy(buf, image_data + off, blk);
//        if (send(sock, buf, blk, 0) < 0) {
//        	 printf("[cam] 发送数据失败, errno: %d\n", errno);
//            break;
//        }
//
//        // 输出发送进度
//        printf("[cam] Sent %u/%u bytes\n", off + blk, img_len);
//    }
//
//    free(buf);  // 释放内存
//    close(sock);
//    printf("[cam] upload done, next shot in 3 s\n");
//    vTaskDelay(pdMS_TO_TICKS(3000));
//}
//
//void create_cam_task(void) {
//    xTaskCreate(cam_task, "cam", 1024, NULL, 4, NULL);
//}
//
