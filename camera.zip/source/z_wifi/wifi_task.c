#include "../z_inc/app_cfg.h"
#include "cy_wcm.h"
#include "FreeRTOS.h"
#include "task.h"
#include "../z_inc/cam_task.h"              /* create_camera_tasks() */
#include <stdbool.h>

#define WIFI_RETRY_DELAY_MS   5000

volatile bool wifi_connected = false;   // WiFi连接状态全局变量

void wifi_event_callback(cy_wcm_event_t event, cy_wcm_event_data_t *event_data)
{
    switch (event)
    {
        case CY_WCM_EVENT_CONNECTED:
            printf("Wi-Fi Connected.\n");
            wifi_connected = true;   // 标记WiFi已连接
            break;

        case CY_WCM_EVENT_DISCONNECTED:
            printf("Wi-Fi Disconnected. Reconnecting...\n");
            wifi_connected = false;  // 连接断开
            NVIC_SystemReset();      // 断开后重启设备
            break;

        case CY_WCM_EVENT_IP_CHANGED:
            printf("IP Address Changed.\n");
            break;

        default:
            break;
    }
}

static void wifi_task(void *arg)
{
    cy_rslt_t res;
    cy_wcm_config_t cfg = { .interface = CY_WCM_INTERFACE_TYPE_STA };

    res = cy_wcm_init(&cfg);
    if (res != CY_RSLT_SUCCESS)
    {
        printf("[wifi] init fail: 0x%08lx\n", (unsigned long)res);
        vTaskDelete(NULL);
    }

    cy_wcm_register_event_callback(wifi_event_callback);

    for (;;)
    {
        cy_wcm_connect_params_t cp = { 0 };
        strncpy((char*)cp.ap_credentials.SSID, WIFI_SSID, CY_WCM_MAX_SSID_LEN);
        strncpy((char*)cp.ap_credentials.password, WIFI_PASSWORD,
                CY_WCM_MAX_PASSPHRASE_LEN);
        cp.ap_credentials.security = CY_WCM_SECURITY_WPA2_AES_PSK;

        cy_wcm_ip_address_t ip;
        printf("[wifi] connect \"%s\" …\n", WIFI_SSID);

        res = cy_wcm_connect_ap(&cp, &ip);
        if (res == CY_RSLT_SUCCESS)
        {
            printf("[wifi] IP %u.%u.%u.%u\n",
                   (ip.ip.v4>>24)&0xFF,(ip.ip.v4>>16)&0xFF,
                   (ip.ip.v4>>8)&0xFF , ip.ip.v4&0xFF);


            // WiFi 连接成功后，主循环保持运行
            for(;;)
            {
                vTaskDelay(pdMS_TO_TICKS(20000));
            }
        }
        else
        {
            printf("[wifi] connect fail, retry\n");
            vTaskDelay(pdMS_TO_TICKS(WIFI_RETRY_DELAY_MS));
        }
    }
}

void create_wifi_task(void)
{
    xTaskCreate(wifi_task, "wifi", 1024, NULL, 3, NULL);
}
